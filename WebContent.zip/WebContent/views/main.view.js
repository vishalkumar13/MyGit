sap.ui.jsview("views.main", {

	/** Specifies the Controller belonging to this View. 
	 * In the case that it is not implemented, or that "null" is returned, this View does not have a Controller.
	 * @memberOf himani_project.main
	 */ 
	getControllerName : function() {
		return "views.main";
	},

	/** Is initially called once after the Controller has been instantiated. It is the place where the UI is constructed. 
	 * Since the Controller is given to this method, its event handlers can be attached right away. 
	 * @memberOf himani_project.main
	 */ 
	createContent : function(oController) {

		var oBar = new sap.m.Bar({
			contentLeft: [new sap.m.Image('myAppIcon', {src: "images/logo.png"})],
			contentMiddle: [new sap.m.Text({text:"Application Title"}).addStyleClass("titleCss")],
			contentRight: [new sap.m.Text({id:"userId", text:"Himani"}).addStyleClass("userIdCss")],
		});

		var oLabel1 = new sap.m.Label({text:"Furnance names : "}).addStyleClass("marginLeft");
		var oInput = new sap.m.Input({id:"input_Furnance",width:'100pt'});

		var oLabel2 = new sap.m.Label({text:"Combobox : "}).addStyleClass("marginLeft");

		var oDropDown = new sap.m.ComboBox({
			id:"comboBox",
			items : [
			         new sap.ui.core.Item({
			        	 text : "A", // string
			        	 key : "A", // string
			         }),
			         new sap.ui.core.Item({
			        	 text : "B", // string
			        	 key : "B", // string
			         }),
			         new sap.ui.core.Item({
			        	 text : "C", // string 	 
			        	 key : "C", // string     	 
			         }),
			         ]});


		var oVBox = new sap.m.HBox({
			items : [oLabel1,oInput ,oLabel2,oDropDown]
		});

		var oTable = new sap.ui.table.Table({
			title: "Production Order List",
			visibleRowCount: 10,
			selectionMode: sap.ui.table.SelectionMode.Single

		});

		oTable.addColumn(new sap.ui.table.Column({
			label: new sap.ui.commons.Label({text: "Wheel NO"}),
			template: new sap.ui.commons.TextField().bindProperty("value", "WheelNo")

		}));
		oTable.addColumn(new sap.ui.table.Column({
			label: new sap.ui.commons.Label({text: "Part No"}),
			template: new sap.ui.commons.TextField().bindProperty("value", "PartNo")

		}));
		oTable.addColumn(new sap.ui.table.Column({
			label: new sap.ui.commons.Label({text: "XRayId"}),
			template: new sap.ui.commons.TextField().bindProperty("value", "XRayId")

		}));

		// Create model and load the model
		var oModel = new sap.ui.model.xml.XMLModel();
		oModel.loadData("/XMII/Illuminator?QueryTemplate=Maheshp/SampleQuery&Content-Type=text/xml");   

		// Set model and bind
		oTable.setModel(oModel);
		oTable.bindRows({path: "/Rowset/Row/"});


		return new sap.m.Page({
			title: "Demo Title",
			showHeader : false,
			content: [
			          oBar,oVBox,oTable
			          ],
			          footer : [
			                    new sap.m.Bar({
			                    	contentRight: [new sap.m.Button({text:"Search",press:oController.onPress})],
			                    })
			                    ]
		});
	}

});